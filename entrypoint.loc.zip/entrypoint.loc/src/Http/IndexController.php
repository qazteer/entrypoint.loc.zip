<?php

namespace App\Http;

use App\Entities\Book;

class IndexController extends Controller
{
    public function indexAction()
    {
        //dump(app()->get('orm')->getEntityManager());

        $entityManager = app()->get('orm')->getEntityManager();
        $book  = new Book();
        $book->title = "Test doctrine";

        $entityManager->persist($book);
        $entityManager->flush();

        return $this->render('index', ['title' => 'Index Page']);
    }
}